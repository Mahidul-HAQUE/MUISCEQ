function music_equalizer_ui()
    % Create the main UI figure
    fig = uifigure('Name', 'Music Equalizer', 'Position', [500 500 300 200]);

    % Title Text
    lbl = uilabel(fig, ...
        'Text', 'Which mode do you want the music equalized?', ...
        'Position', [30 140 250 30], ...
        'FontSize', 12);

    % Manual Mode Button
    manualBtn = uibutton(fig, 'push', ...
        'Text', 'Manual Mode', ...
        'Position', [50 80 200 30], ...
        'ButtonPushedFcn', @(btn, event) setMode(2, fig));  % Pass fig to setMode

    % Preset Mode Button
    presetBtn = uibutton(fig, 'push', ...
        'Text', 'Preset Mode', ...
        'Position', [50 40 200 30], ...
        'ButtonPushedFcn', @(btn, event) setMode(1, fig));  % Pass fig to setMode
end

% Callback Function to Set globalIndex and Open Simulink Model
function setMode(modeValue, fig)
    modelName = 'PRMU';  % Replace with your Simulink model name (without .slx)

    % Check if globalIndex exists, else create it
    if ~evalin('base', 'exist(''globalIndex'', ''var'')')
        globalIndex = Simulink.Parameter;
        globalIndex.CoderInfo.StorageClass = 'ExportedGlobal';
    else
        globalIndex = evalin('base', 'globalIndex');  % Access global variable
    end

    % Set the mode (1 for Preset, 2 for Manual)
    globalIndex.Value = modeValue;
    assignin('base', 'globalIndex', globalIndex);  % Update in MATLAB Workspace

    % Display confirmation message
    if modeValue == 2
        uialert(fig, 'Manual Mode Selected (globalIndex = 2)', 'Mode Selected');
    else
        uialert(fig, 'Preset Mode Selected (globalIndex = 1)', 'Mode Selected');
    end

    % ✅ Load the Simulink model if not already loaded
    if ~bdIsLoaded(modelName)
        try
            load_system(modelName);
        catch
            uialert(fig, sprintf('Error: Model "%s" not found.', modelName), 'Model Error');
            return;  % Exit the function if the model cannot be loaded
        end
    end

    % ✅ Open the Simulink model
    open_system(modelName);

    % Optional: Trigger Simulink update
    set_param(modelName, 'SimulationCommand', 'update');
end
